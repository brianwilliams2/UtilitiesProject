﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


public class MenuController : MonoBehaviour {

    public GameObject pauseMenu;
    public bool isPaused;

    private static int score;
    public Text changingText;
    private static int lives;
    public Text changingText2;


    // Use this for initialization
    void Start ()
    {
        
	}
	
	// Update is called once per frame
	void Update ()
    {
        //constantly updates the lives/score
        LivesUpdate();
        ScoreUpdate();
        //open/close menu when esc is pressed
		if(Input.GetKeyDown(KeyCode.Escape))
        {
            if(isPaused)
            {
                resumeGame();
            }
            else
            {
                isPaused = true;
                pauseMenu.SetActive(true);
                Time.timeScale = 0f;
            }
        }
	}
    //closes menu, resume time
    public void resumeGame()
    {
        isPaused = false;
        pauseMenu.SetActive(false);
        Time.timeScale = 1f;
    }


    public void ResetGame()
    {
        //reload current scene,resumes time and resets lives/score
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        Time.timeScale = 1f;
        Alien.Points = 0;
        PlayerController.PlayerLives = 4;
    }

    public void ScoreUpdate()
    {
        //Update score text with points variable in alien script
        score = Alien.Points;
        changingText.text = "Current Score: " + score.ToString();
    }

    public void LivesUpdate()
    {
        //update lives left with lives variable from playercontroller
        lives = PlayerController.PlayerLives;
        changingText2.text = "Lives Left: " + lives.ToString();
    }


}
